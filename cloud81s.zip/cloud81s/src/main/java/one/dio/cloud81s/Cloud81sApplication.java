package one.dio.cloud81s;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cloud81sApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cloud81sApplication.class, args);
	}

}
