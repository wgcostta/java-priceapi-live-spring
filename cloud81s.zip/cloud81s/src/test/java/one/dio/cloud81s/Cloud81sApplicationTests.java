package one.dio.cloud81s;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cloud81sApplicationTests {

	@Test
	void contextLoads() {
	}

}
